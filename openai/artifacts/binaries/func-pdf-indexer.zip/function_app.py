import logging
import azure.functions as func
from pdfindexer import pdfindexerfunc
from delete import delete
from deleteDocument import deleteDocument
from deleteAll import deleteAll
import json


app = func.FunctionApp()
@app.function_name(name="pdfindexer")
@app.route(route="pdfindexer",auth_level=func.AuthLevel.ANONYMOUS)
def test_function(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    
    file = req.files.get('pdf') or None
    logging.info("file")
    logging.info(file)
        
    index_name_ = req.form.get('index_name')
    container_name_ = req.form.get('container_name')

    blob_url = req.form.get('blob_url')
    if not (index_name_) or not (container_name_):
        if not file:
            error = {
                    "error": "index/container/file not provided correctly"
                }
        elif not blob_url:
            error = {
                    "error": "index/container/blob_url not provided correctly"
                }
        response = func.HttpResponse(json.dumps(error))
        response.headers['Content-Type'] = 'application/json'
        return response

    output = pdfindexerfunc(file,index_name_,container_name_,blob_url)

    response = func.HttpResponse(json.dumps(output))
    response.headers['Content-Type'] = 'application/json'
    return response






@app.function_name(name="delete")
@app.route(route="delete",auth_level=func.AuthLevel.ANONYMOUS)
def test_function(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    try:
        req_body = req.get_json()
        index_name = req_body['index_name']
        container_name = req_body['container_name']
    except:
        error = {
            "error": "index or container name not provided"
        }
        response = func.HttpResponse(json.dumps(error))
        response.headers['Content-Type'] = 'application/json'
        return response
    if not (index_name) or not (container_name):
        error = {
                "error": "index/container not provided correctly"
            }
        response = func.HttpResponse(json.dumps(error))
        response.headers['Content-Type'] = 'application/json'
        return response
    output = delete(index_name,container_name)

    response = func.HttpResponse(json.dumps(output))
    response.headers['Content-Type'] = 'application/json'
    return response



@app.function_name(name="deleteDocument")
@app.route(route="deleteDocument",auth_level=func.AuthLevel.ANONYMOUS)
def test_function(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    try:
        req_body = req.get_json()
        index_name = req_body['index_name']
        file_name = req_body['file_name']
    except:
        error = {
            "error": "index or file name not provided"
        }
        response = func.HttpResponse(json.dumps(error))
        response.headers['Content-Type'] = 'application/json'
        return response
    if not (index_name) or not (file_name):
        error = {
                "error": "index/file not provided correctly"
            }
        response = func.HttpResponse(json.dumps(error))
        response.headers['Content-Type'] = 'application/json'
        return response
    output = deleteDocument(index_name,file_name)

    response = func.HttpResponse(json.dumps(output))
    response.headers['Content-Type'] = 'application/json'
    return response


@app.function_name(name="deleteAll")
@app.route(route="deleteAll",auth_level=func.AuthLevel.ANONYMOUS)
def test_function(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

  

    output = deleteAll(req)

    response = func.HttpResponse(json.dumps(output))
    response.headers['Content-Type'] = 'application/json'
    return response

