import json
import logging
from requests.exceptions import RequestException
import logging

import azure.functions as func
from image_generation import generate_images

app = func.FunctionApp()



@app.function_name(name="Regenerate_Dalle")
@app.route(route="regenerate-dalle",auth_level=func.AuthLevel.ANONYMOUS)
def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        json_body = req.get_json()
        list_url = generate_images(json_body['dalle_prompt'])
        json_body['recommendedItems']={}
        
        for i in range(len(list_url)):
            key = "Recommended Item " + str(1+i)
            json_body['recommendedItems'][key] = list_url[i]
            
        json_data = json.dumps(json_body)
        return func.HttpResponse(json_data, status_code=200, mimetype="application/json")
    
    except RequestException as e:
        error_message = f"An error occurred while processing the request: {str(e)}"
        logging.error(error_message)
        return func.HttpResponse(status_code=500, body=error_message, mimetype="text/plain")
