
import json
import openai
import time
import azure.functions as func
import logging
import os
import re
import func_timeout


AZURE_OPENAI_SERVICE_KEY = os.environ.get("AZURE_OPENAI_SERVICE_KEY") or "#OPENAI_PRIMARY_KEY#"
AZURE_OPENAI_SERVICE = os.environ.get("AZURE_OPENAI_SERVICE") or "#OPENAI_SERVICE_NAME#"

API_KEY = AZURE_OPENAI_SERVICE_KEY
openai.api_key = API_KEY
api_key = API_KEY

api_version = '2022-08-03-preview'
AZURE_OPENAI_GPT_DEPLOYMENT = os.environ.get("AZURE_OPENAI_MODEL_DEPLOYMENT") or "#OPENAI_MODEL_DEPLOYMENT_NAME#"
AZURE_OPENAI_CHATGPT_DEPLOYMENT = os.environ.get("AZURE_OPENAI_MODEL_ENGINE_DEPLOYMENT") or "#OPENAI_MODEL_ENGINE_NAME#"
deployment_name = AZURE_OPENAI_GPT_DEPLOYMENT
ENGINE = AZURE_OPENAI_CHATGPT_DEPLOYMENT

openai.api_type = "azure"
openai.api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com"
openai.api_version = "2023-03-15-preview"


def openaiCompletion(my_argument):
    prompt = my_argument[0]
    t = my_argument[1]
    logging.info(prompt)
    response = openai.Completion.create(
            engine = ENGINE,
            prompt= prompt,
            temperature=t,
            max_tokens=1000,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0,
            best_of=1,
            stop=None)
    res = response['choices'][0]['text']
    res = res.strip()
    res = res.replace('\'s','s')
    res = res.replace('\'t','t')
    return res

def run_function(f,my_argument,max_wait,default_value):
    try:
        logging.info("Generation Success")
        return func_timeout.func_timeout(max_wait, openaiCompletion,args=[my_argument])
    except func_timeout.FunctionTimedOut:
        pass
    logging.info("Generation Failed - sending default text")
    return default_value


app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="campaign_generation")
def campaign_generation(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    ##############INPUT########################
    desc = req.params.get('description')
    if not desc:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            desc = req_body.get('description')
    if desc is None:
        desc = str(req.form.getlist('description')[0])
      
    type_of_campaign = req.params.get('type')
    if not type_of_campaign:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            type_of_campaign = req_body.get('type')
    if type_of_campaign is None:
        type_of_campaign = str(req.form.getlist('type')[0])

    creative_factor = req.params.get('creative_factor')
    if not creative_factor:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            creative_factor = req_body.get('creative_factor')
    if creative_factor is None:
        creative_factor = str(req.form.getlist('creative_factor')[0])

    #####################PROMPT#########################
    try:
        #res = openaiCompletion(prompt,float(creative_factor))
        default_text = '''Say hello to a better life with our amazing product! 🥰🤩
\nOur top-quality product is designed to help you reach your health and performance goals, enabling you to make the most of every moment. 💪✌️ Enjoy the improved health, optimal performance, and goal success that you deserve. 🤯🎉 Life can be hard and complicated.
\nBut setting goals so clear creates.
\nAchieve success, a brighter view,
\nAnd take care of yourself too.Our product is the answer to A better life it can ensue.
\n#betterlifeproduct #betterlife #optimalperformance #healthgoals'''

        default_title = "Start Your Journey to a Better Life Today!"


        logging.info("generating text")
        prompt = "Create " + str(type_of_campaign) + " campaign on following info:" + desc + "."
        start_time = time.time()
        x = run_function(openaiCompletion,[prompt,float(creative_factor)],15,default_text)
        res = x
        logging.info(f"Text generation took {time.time() - start_time} seconds")
        
        
        logging.info("generating title")
        prompt_title = f"Generate a title based for the below given post, return just the title without any extra supporting words. The title must be catchy.\n Text:{res}\nTitle:".format(res=res)
        start_time = time.time()
        x = run_function(openaiCompletion,[prompt_title,float(creative_factor)],10,default_title)
        title = x
        logging.info(f"Title generation took {time.time() - start_time} seconds")
        
        unwanted_characters = '/"#'
        clean_title = re.sub(f'[{re.escape(unwanted_characters)}]', '', title)

        #####################OUTPUT#########################
        jsn={}
        jsn['prompt'] = prompt
        jsn["campaign"] = res
        jsn["title"] = clean_title
 
        jsno = json.dumps(jsn,indent=1)
        #if req.method == "POST":
        return func.HttpResponse(jsno, status_code=200, mimetype="application/json")
    
    except Exception as e:
        return func.HttpResponse(str(e), status_code=500)



    
