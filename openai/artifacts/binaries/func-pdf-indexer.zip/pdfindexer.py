
import logging
import azure.functions as func
import os
import argparse
import glob
import html
import io
import re
import time
import json
import tempfile
import PyPDF2
import requests
import time
from azure.core.credentials import AzureKeyCredential
from pypdf import PdfReader, PdfWriter
from azure.core.credentials import AzureKeyCredential
from azure.storage.blob import BlobServiceClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import ( SearchIndex, PrioritizedFields, SemanticField, SemanticSettings, SimpleField, SearchableField, SemanticConfiguration)
from azure.search.documents import SearchClient
from azure.ai.formrecognizer import DocumentAnalysisClient
import random
import multiprocessing
import string
MAX_SECTION_LENGTH = 1000
SENTENCE_SEARCH_LIMIT = 100
SECTION_OVERLAP = 100


search_service_name = os.environ.get("SEARCH_SERVICE_NAME")
search_service_key = os.environ.get("SEARCH_SERVICE_KEY")
storage_account_key = os.environ.get("STORAGE_ACCOUNT_KEY")
storage_account_name = os.environ.get("STORAGE_ACCOUNT_NAME")
form_recognizer_key = os.environ.get("FORM_RECOGNIZER_KEY")

FormRecognizerService = os.environ.get("FormRecognizerService")
form_recognizer_header = os.environ.get("form_recognizer_header")

search_creds = AzureKeyCredential(search_service_key)
formrecognizer_creds = AzureKeyCredential(form_recognizer_key)


def generate_name(length):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(length))


def blob_name_from_file_page(filename, page = 0):
    if os.path.splitext(filename)[1].lower() == ".pdf":
        return os.path.splitext(os.path.basename(filename))[0] + f"-{page}" + ".pdf"
    else:
        return os.path.basename(filename)

def upload_blobs(file, container_name):
    blob_service = BlobServiceClient(
        account_url=f"https://{storage_account_name}.blob.core.windows.net",
        credential=storage_account_key
    )
    logging.info("authh")
    #container_name = "content"
    blob_container = blob_service.get_container_client(container_name)

    if not blob_container.exists():
        logging.info("creating container")
        blob_container.create_container()
    logging.info("created container")
    # Upload file or pages to blob storage
    if file.filename.lower().endswith(".pdf"):
        logging.info("Uploading PDF pages as separate blobs")
        reader = PdfReader(file.stream)
        pages = reader.pages
        for i, page in enumerate(pages):
            blob_name = blob_name_from_file_page(file.filename, i)
            blob_client = blob_container.get_blob_client(blob_name)

            with io.BytesIO() as f:
                writer = PdfWriter()
                writer.add_page(page)
                writer.write(f)
                f.seek(0)

                blob_client.upload_blob(f, overwrite=True)
    else:
        logging.info("Uploading non-PDF file as a single blob")
        blob_name = file.filename
        blob_client = blob_container.get_blob_client(blob_name)
        blob_client.upload_blob(file.stream, overwrite=True)


def remove_blobs(filename):
   
    blob_service = BlobServiceClient(account_url=f"https://{storage_account_name}.blob.core.windows.net", credential=storage_creds)
    blob_container = blob_service.get_container_client(container_name)
    if blob_container.exists():
        if filename == None:
            blobs = blob_container.list_blob_names()
        else:
            prefix = os.path.splitext(os.path.basename(filename))[0]
            blobs = filter(lambda b: re.match(f"{prefix}-\d+\.pdf", b), blob_container.list_blob_names(name_starts_with=os.path.splitext(os.path.basename(prefix))[0]))
        for b in blobs:
        
            blob_container.delete_blob(b)
def table_to_html(table):
    table_html = "<table>"
    rows = [sorted([cell for cell in table.cells if cell.row_index == i], key=lambda cell: cell.column_index) for i in range(table.row_count)]
    for row_cells in rows:
        table_html += "<tr>"
        for cell in row_cells:
            tag = "th" if (cell.kind == "columnHeader" or cell.kind == "rowHeader") else "td"
            cell_spans = ""
            if cell.column_span > 1: cell_spans += f" colSpan={cell.column_span}"
            if cell.row_span > 1: cell_spans += f" rowSpan={cell.row_span}"
            table_html += f"<{tag}{cell_spans}>{html.escape(cell.content)}</{tag}>"
        table_html +="</tr>"
    table_html += "</table>"
    return table_html

import io
# def get_document_text(file_stream,filename):
#     offset = 0
#     page_map = []
#     page_num = 0

#     form_recognizer_client = DocumentAnalysisClient(
#         endpoint=f"https://common-ai-formrecognizer-dev.cognitiveservices.azure.com/",
#         credential=formrecognizer_creds,
#         headers={"x-ms-useragent": "azure-search-chat-demo/1.0.0"}
#     )

#     if filename.lower().endswith(".pdf"):
#         logging.info("Processing PDF file")
#         reader = PdfReader(file_stream)
#         pages = reader.pages
        
#         # Iterate over pages in groups of 3
#         i = 0
#         for i in range(1):
#             page_group = pages[i:i+1]
#             page_num += len(page_group)
#             logging.info("page numbers*****")
#             logging.info(page_num)
            
#             with io.BytesIO() as f:
#                 writer = PdfWriter()
#                 for page in pages:
#                     writer.add_page(page)
#                 writer.write(f)
#                 f.seek(0)
#                 try:
#                     poller = form_recognizer_client.begin_analyze_document("prebuilt-layout", document=f)
#                     form_recognizer_results = poller.result()

#                     for page_num, page in enumerate(form_recognizer_results.pages):
#                         tables_on_page = [table for table in form_recognizer_results.tables if table.bounding_regions[0].page_number == page_num + 1]

#                         # mark all positions of the table spans in the page
#                         page_offset = page.spans[0].offset
#                         page_length = page.spans[0].length
#                         table_chars = [-1]*page_length
#                         for table_id, table in enumerate(tables_on_page):
#                             for span in table.spans:
#                                 # replace all table spans with "table_id" in table_chars array
#                                 for i in range(span.length):
#                                     idx = span.offset - page_offset + i
#                                     if idx >=0 and idx < page_length:
#                                         table_chars[idx] = table_id

#                         #build page text by replacing charcters in table spans with table html
#                         page_text = ""
#                         added_tables = set()
#                         for idx, table_id in enumerate(table_chars):
#                             if table_id == -1:
#                                 page_text += form_recognizer_results.content[page_offset + idx]
#                             elif not table_id in added_tables:
#                                 page_text += table_to_html(tables_on_page[table_id])
#                                 added_tables.add(table_id)

#                         page_text += " "
#                         page_map.append((page_num, offset, page_text))
#                         offset += len(page_text)

             
#                         # page_text = ""
#                         # for table in form_recognizer_results.tables:
#                         #     page_text += table_to_html(table) + " "
#                         # page_text += form_recognizer_results.content
#                         # page_text += " "
#                         # page_map.append((page_num, offset, page_text.encode('utf-8').decode('ascii', 'ignore')))
#                         # offset += len(page_text)
#                 except Exception as e:
#                     logging.error(f"Error processing pages {i+1}-{i+3} of PDF file: {e}")
#             i += 1


#     return page_map




def get_document_text(file_stream,filename):
    offset = 0
    page_map = []
    page_num = 0

    form_recognizer_client = DocumentAnalysisClient(
        endpoint=f"https://{FormRecognizerService}.cognitiveservices.azure.com/",
        credential=formrecognizer_creds,
        headers={"x-ms-useragent": form_recognizer_header}
    )

    if filename.lower().endswith(".pdf"):
        logging.info("Processing PDF file")
        reader = PdfReader(file_stream)
        pages = reader.pages
        
        # Iterate over pages in groups of 3
        i = 0
        while i < len(pages):
            page_group = pages[i:i+20]
            page_num += len(page_group)
            logging.info("page numbers*****")
            logging.info(page_num)
            
            with io.BytesIO() as f:
                writer = PdfWriter()
                for page in page_group:
                    writer.add_page(page)
                writer.write(f)
                f.seek(0)
                try:
                    poller = form_recognizer_client.begin_analyze_document("prebuilt-layout", document=f)
                    form_recognizer_results = poller.result()

                    for page_num2, page in enumerate(form_recognizer_results.pages):
                        tables_on_page = [table for table in form_recognizer_results.tables if table.bounding_regions[0].page_number == page_num2 + 1]

                        # mark all positions of the table spans in the page
                        page_offset = page.spans[0].offset
                        page_length = page.spans[0].length
                        table_chars = [-1]*page_length
                        for table_id, table in enumerate(tables_on_page):
                            for span in table.spans:
                                # replace all table spans with "table_id" in table_chars array
                                for i in range(span.length):
                                    idx = span.offset - page_offset + i
                                    if idx >=0 and idx < page_length:
                                        table_chars[idx] = table_id

                        # build page text by replacing charcters in table spans with table html
                        page_text = ""
                        added_tables = set()
                        for idx, table_id in enumerate(table_chars):
                            if table_id == -1:
                                page_text += form_recognizer_results.content[page_offset + idx]
                            elif not table_id in added_tables:
                                page_text += table_to_html(tables_on_page[table_id])
                                added_tables.add(table_id)

                        page_text += " "
                        page_map.append((page_num2, offset, page_text))
                        offset += len(page_text)

             
                        # page_text = ""
                        # for table in form_recognizer_results.tables:
                        #     page_text += table_to_html(table) + " "
                        # page_text += form_recognizer_results.content
                        # page_text += " "
                        # page_map.append((page_num, offset, page_text.encode('utf-8').decode('ascii', 'ignore')))
                        # offset += len(page_text)
                except Exception as e:
                    logging.error(f"Error processing pages {i+1}-{i+3} of PDF file: {e}")
            i += 20


    return page_map


def get_document_text_blob(file_content,filename):
    offset = 0
    page_map = []
    page_num = 0

    form_recognizer_client = DocumentAnalysisClient(
        endpoint=f"https://{FormRecognizerService}.cognitiveservices.azure.com/",
        credential=formrecognizer_creds,
        headers={"x-ms-useragent": form_recognizer_header}
    )

    if filename.lower().endswith(".pdf"):
        with io.BytesIO(file_content) as file_stream:
            file_stream.seek(0) 
            logging.info("Processing PDF file 2")
            reader = PdfReader(file_stream)
            pages = reader.pages
        
            # Iterate over pages in groups of 3
            i = 0
            while i < len(pages):
                page_group = pages[i:i+20]
                page_num += len(page_group)
                logging.info("page numbers*****")
                logging.info(page_num)
                
                with io.BytesIO() as f:
                    writer = PdfWriter()
                    for page in page_group:
                        writer.add_page(page)
                    writer.write(f)
                    page_group_content = f.getvalue()
                
                        
                    try:
                        poller = form_recognizer_client.begin_analyze_document("prebuilt-layout", document=page_group_content)
                        form_recognizer_results = poller.result()

                        for page_num2, page in enumerate(form_recognizer_results.pages):
                            tables_on_page = [table for table in form_recognizer_results.tables if table.bounding_regions[0].page_number == page_num2 + 1]

                                    # mark all positions of the table spans in the page
                            page_offset = page.spans[0].offset
                            page_length = page.spans[0].length
                            table_chars = [-1]*page_length
                            for table_id, table in enumerate(tables_on_page):
                                for span in table.spans:
                                        # replace all table spans with "table_id" in table_chars array
                                    for i in range(span.length):
                                        idx = span.offset - page_offset + i
                                        if idx >=0 and idx < page_length:
                                            table_chars[idx] = table_id

                                    # build page text by replacing charcters in table spans with table html
                            page_text = ""
                            added_tables = set()
                            for idx, table_id in enumerate(table_chars):
                                if table_id == -1:
                                    page_text += form_recognizer_results.content[page_offset + idx]
                                elif not table_id in added_tables:
                                    page_text += table_to_html(tables_on_page[table_id])
                                    added_tables.add(table_id)

                            page_text += " "
                            page_map.append((page_num2, offset, page_text))
                            offset += len(page_text)

                        
                                    # page_text = ""
                                    # for table in form_recognizer_results.tables:
                                    #     page_text += table_to_html(table) + " "
                                    # page_text += form_recognizer_results.content
                                    # page_text += " "
                                    # page_map.append((page_num, offset, page_text.encode('utf-8').decode('ascii', 'ignore')))
                                    # offset += len(page_text)
                    except Exception as e:
                        logging.error(f"Error processing pages {i+1}-{i+3} of PDF file: {e}")
                i += 20


    return page_map

# .encode('utf-8').decode('ascii', 'ignore')
def get_document_text_full(file_stream):
    offset = 0
    page_map = []
    page_num = 0

    form_recognizer_client = DocumentAnalysisClient(
        endpoint=f"https://{FormRecognizerService}.cognitiveservices.azure.com/",
        credential=formrecognizer_creds,
        headers={"x-ms-useragent": form_recognizer_header}
    )

    if file_stream.filename.lower().endswith(".pdf"):
        logging.info("Processing PDF file")
        reader = PdfReader(file_stream)
        pages = reader.pages
        
        # Iterate over pages in groups of 3
        i = 0
        while i < len(pages):
            page_group = pages[i:i+20]
            page_num += len(page_group)
            logging.info("page numbers*****")
            logging.info(page_num)
            
            with io.BytesIO() as f:
                writer = PdfWriter()
                for page in page_group:
                    writer.add_page(page)
                writer.write(f)
                f.seek(0)
                try:
                    poller = form_recognizer_client.begin_analyze_document("prebuilt-layout", document=f)
                    form_recognizer_results = poller.result()

                    for page_num2, page in enumerate(form_recognizer_results.pages):
                        tables_on_page = [table for table in form_recognizer_results.tables if table.bounding_regions[0].page_number == page_num2 + 1]

                        # mark all positions of the table spans in the page
                        page_offset = page.spans[0].offset
                        page_length = page.spans[0].length
                        table_chars = [-1]*page_length
                        for table_id, table in enumerate(tables_on_page):
                            for span in table.spans:
                                # replace all table spans with "table_id" in table_chars array
                                for i in range(span.length):
                                    idx = span.offset - page_offset + i
                                    if idx >=0 and idx < page_length:
                                        table_chars[idx] = table_id

                        # build page text by replacing charcters in table spans with table html
                        page_text = ""
                        added_tables = set()
                        for idx, table_id in enumerate(table_chars):
                            if table_id == -1:
                                page_text += form_recognizer_results.content[page_offset + idx]
                            elif not table_id in added_tables:
                                page_text += table_to_html(tables_on_page[table_id])
                                added_tables.add(table_id)

                        page_text += " "
                        page_map.append((page_num2, offset, page_text))
                        offset += len(page_text)

             
                    # page_text = ""
                    # for table in form_recognizer_results.tables:
                    #     page_text += table_to_html(table) + " "
                    # page_text += form_recognizer_results.content
                    # page_text += " "
                    # page_map.append((page_num, offset, page_text.encode('utf-8').decode('ascii', 'ignore')))
                    # offset += len(page_text)
                except Exception as e:
                    logging.error(f"Error processing pages {i+1}-{i+3} of PDF file: {e}")
            i += 20


    return page_map


def split_text(page_map):
    SENTENCE_ENDINGS = [".", "!", "?"]
    WORDS_BREAKS = [",", ";", ":", " ", "(", ")", "[", "]", "{", "}", "\t", "\n"]


    def find_page(offset):
        l = len(page_map)
        for i in range(l - 1):
            if offset >= page_map[i][1] and offset < page_map[i + 1][1]:
                return i
        return l - 1

    all_text = "".join(p[2] for p in page_map)
    length = len(all_text)
    start = 0
    end = length
    while start + SECTION_OVERLAP < length:
        last_word = -1
        end = start + MAX_SECTION_LENGTH

        if end > length:
            end = length
        else:
            # Try to find the end of the sentence
            while end < length and (end - start - MAX_SECTION_LENGTH) < SENTENCE_SEARCH_LIMIT and all_text[end] not in SENTENCE_ENDINGS:
                if all_text[end] in WORDS_BREAKS:
                    last_word = end
                end += 1
            if end < length and all_text[end] not in SENTENCE_ENDINGS and last_word > 0:
                end = last_word # Fall back to at least keeping a whole word
        if end < length:
            end += 1

        # Try to find the start of the sentence or at least a whole word boundary
        last_word = -1
        while start > 0 and start > end - MAX_SECTION_LENGTH - 2 * SENTENCE_SEARCH_LIMIT and all_text[start] not in SENTENCE_ENDINGS:
            if all_text[start] in WORDS_BREAKS:
                last_word = start
            start -= 1
        if all_text[start] not in SENTENCE_ENDINGS and last_word > 0:
            start = last_word
        if start > 0:
            start += 1

        section_text = all_text[start:end]
        yield (section_text, find_page(start))

        last_table_start = section_text.rfind("<table")
        if (last_table_start > 2 * SENTENCE_SEARCH_LIMIT and last_table_start > section_text.rfind("</table")):
            # If the section ends with an unclosed table, we need to start the next section with the table.
            # If table starts inside SENTENCE_SEARCH_LIMIT, we ignore it, as that will cause an infinite loop for tables longer than MAX_SECTION_LENGTH
            # If last table starts inside SECTION_OVERLAP, keep overlapping

            start = min(end - SECTION_OVERLAP, start + last_table_start)
        else:
            start = end - SECTION_OVERLAP
        
    if start + SECTION_OVERLAP < end:
        yield (all_text[start:end], find_page(start))

def create_sections(filename, page_map):
    for i, (section, pagenum) in enumerate(split_text(page_map)):
        logging.info("pagenummm")
        logging.info(i)
        yield {
            "id": re.sub("[^0-9a-zA-Z_-]","_",f"{filename}-{i}"),
            "content": section,
            "category": None,
            "sourcepage": blob_name_from_file_page(filename, pagenum),
            "sourcefile": filename
        }

def create_search_index(index_name):

    index_client = SearchIndexClient(endpoint=f"https://{search_service_name}.search.windows.net",
                                     credential=search_creds)
    if index_name not in index_client.list_index_names():
        index = SearchIndex(
            name=index_name,
            fields=[
                SimpleField(name="id", type="Edm.String", key=True),
                SearchableField(name="content", type="Edm.String", analyzer_name="en.microsoft"),
                SimpleField(name="category", type="Edm.String", filterable=True, facetable=True),
                SimpleField(name="sourcepage", type="Edm.String", filterable=True, facetable=True),
                SimpleField(name="sourcefile", type="Edm.String", filterable=True, facetable=True)
            ],
            semantic_settings=SemanticSettings(
                configurations=[SemanticConfiguration(
                    name='default',
                    prioritized_fields=PrioritizedFields(
                        title_field=None, prioritized_content_fields=[SemanticField(field_name='content')]))])
        )

        try:
            time.sleep(2)
            index_client.create_index(index)
        except Exception as e:
            # Handle case when index already exists
            logging.info(e)
            
    

def index_sections(filename, sections, index_name):

    search_client = SearchClient(endpoint=f"https://{search_service_name}.search.windows.net",
                                    index_name=index_name,
                                    credential=search_creds)
    i = 0
    batch = []
    for s in sections:
        batch.append(s)
        i += 1

        if i % 1000 == 0:
            results = search_client.upload_documents(documents=batch)
            succeeded = sum([1 for r in results if r.succeeded])

            batch = []

    if len(batch) > 0:
        results = search_client.upload_documents(documents=batch)
        succeeded = sum([1 for r in results if r.succeeded])
def upload_blobs_from_url(file, container_name, filename):
    blob_service = BlobServiceClient(
        account_url=f"https://{storage_account_name}.blob.core.windows.net",
        credential=storage_account_key
    )

    #container_name = "content"
    blob_container = blob_service.get_container_client(container_name)
    if not blob_container.exists():
        logging.info("creating container")
        blob_container.create_container()

    with io.BytesIO(file) as f:
        if f.read(4) == b'%PDF':
            f.seek(0)
            logging.info("Processing PDF file")
            reader = PdfReader(f)
            pages = reader.pages
        
            for i, page in enumerate(pages):
                blob_name = blob_name_from_file_page(filename, i)
                blob_client = blob_container.get_blob_client(blob_name)

                with io.BytesIO() as f:
                    writer = PdfWriter()
                    writer.add_page(page)
                    writer.write(f)
                    f.seek(0)

                    blob_client.upload_blob(f, overwrite=True)

import re

def get_container_and_blob_names_from_blob_url(blob_url):
    """Extracts the container name and blob name from an Azure Blob URL."""
    pattern = r"https?://(?P<account_name>[^\.]+)\.blob\.core\.windows\.net/(?P<container_name>[^/]+)/(?P<blob_name>[^/]+)"
    match = re.match(pattern, blob_url)
    container_name = match.group("container_name")
    blob_name = match.group("blob_name")
    return container_name, blob_name
def remove_from_index(filename,index_name):

    search_client = SearchClient(endpoint=f"https://{search_service_name}.search.windows.net/",
                                    index_name=index_name,
                                    credential=search_creds)
    while True:
        filter = None if filename == None else f"sourcefile eq '{os.path.basename(filename)}'"
        r = search_client.search("", filter=filter, top=1000, include_total_count=True)
        if r.get_count() == 0:
            break
        r = search_client.delete_documents(documents=[{ "id": d["id"] } for d in r])

        # It can take a few seconds for search results to reflect changes, so wait a bit
        time.sleep(2)
index_list = ['finance', 'gm-demo','gm-demo-test','gptkbindex','healthcare','ralph-lauren','ralph-lauren-v2','retail']
# app = func.FunctionApp()
# @app.function_name(name="pdfindexerprod")
# @app.route(route="pdfindexerprod")
# req: func.HttpRequest
#  -> func.HttpResponse
def pdfindexerfunc(file_whole,index,container,blob_url):
    logging.info('Python HTTP trigger function processed a request.')
    try:
    # Get the file from the request
        # file = req.files.get('pdf')
        # logging.info("file")
        # logging.info(file)
     
        # index_name_ = req.form.get('index_name')
        # container_name_ = req.form.get('container_name')
        file = file_whole
        index_name_ = index
        container_name_ = container
        logging.info(file)

        if file and (index_name_ not in index_list) and (container_name_ not in index_list):
            # Get the name of the file
            filename = file.filename
            logging.info("filename")
            logging.info(filename)
  
            # with open(file_path, 'wb') as f:
            #     f.write(file.stream.read())
            index_storage_name = index_name_
            storage_name = container_name_
            index_name = index_storage_name
            container_name = storage_name
            create_search_index(index_name)
           
         
            page_map = get_document_text(file, filename)
           
            # print("*****************************************")
            # print(page_map)
            
            sections = create_sections(file.filename, page_map)
            index_sections(file.filename, sections, index_name)
            upload_blobs(file, container_name)
            # upload_blobs(file)
            output = {
                "index_name": index_name,
                "container_name": container_name
            }
            # response = func.HttpResponse(json.dumps(output))
            # response.headers['Content-Type'] = 'application/json'
            return output
        elif blob_url and not file and (index_name_ not in index_list) and (container_name_ not in index_list):
            logging.info("in blob urll")
            # container_name, blob_name = get_container_and_blob_names_from_blob_url(blob_url)
            # blob_stream = io.BytesIO()
            # blob_service = BlobServiceClient(
            #     account_url=f"https://{storage_account_name}.blob.core.windows.net"
            # )

            # blob_container = blob_service.get_container_client(container_name)
            
            # blob_client = blob_container.get_blob_client(blob_name)
            # logging.info("after blob client")
            # download_stream = blob_client.download_blob()
            # logging.info("after download")
            # logging.info(type(download_stream))
            # blob_stream.write(download_stream.content_as_bytes())
            
            response = requests.get(blob_url)
                
            logging.info("after write")
            # response.seek(0)
            logging.info("after seek")
            filename = os.path.basename(blob_url)
            if '.pdf' not in filename:
                filename = filename + '.pdf'
            logging.info("after filename")
            with io.BytesIO(response.content) as f:
                if f.read(4) == b'%PDF':
                   
                   
                    pdf_reader = PdfReader(f)
                    pages = len(pdf_reader.pages)
                    logging.info("pages")
                    logging.info(pages)
                    create_search_index(index_name_)
                    page_map = get_document_text_blob(response.content,filename)
                    logging.info("after page map")
                    sections = create_sections(filename, page_map)
                    logging.info("after sections")
                    index_sections(filename, sections, index_name_)
                    
                    upload_blobs_from_url(response.content, container_name_, filename)
                    output = {
                        "index_name": index_name_,
                        "container_name": container_name_
                    }
                    return output
        else:
            output = {
                "error": 'Please pass the file/blob_url correctly'
            }
            # response = func.HttpResponse(json.dumps(output))
            # response.headers['Content-Type'] = 'application/json'
            return output

    except Exception as e:
        logging.info("in except")
        logging.info(e)
        error = {
            "error": e
        }
        return error

    else:
        return func.HttpResponse(
             "Please pass a PDF file in the request.",
             status_code=400
        )
