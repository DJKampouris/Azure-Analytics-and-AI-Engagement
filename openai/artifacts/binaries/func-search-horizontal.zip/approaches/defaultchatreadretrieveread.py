import openai
from azure.search.documents import SearchClient
from azure.search.documents.models import QueryType
from approaches.approach import Approach
from text import nonewlines
import logging


# Simple retrieve-then-read implementation, using the Cognitive Search and OpenAI APIs directly. It first retrieves
# top documents from search, then constructs a prompt with them, and then uses OpenAI to generate an completion 
# (answer) with that prompt.
class DefaultChatReadRetrieveReadApproach(Approach):
    

    def __init__(self, search_client: SearchClient, chatgpt_deployment: str, gpt_deployment: str, sourcepage_field: str, content_field: str):
        self.search_client = search_client
        # self.chatgpt_deployment = "gpt3-5_turbo"
        # self.gpt_deployment = "clinical-notes"
        self.chatgpt_deployment = chatgpt_deployment
        self.gpt_deployment = gpt_deployment
        self.sourcepage_field = sourcepage_field
        self.content_field = content_field
        

    def run(self, history: list[dict], overrides: dict, use_public_information,company="default", prompt_config={}) -> any: 
        
        if prompt_config != {}:
            values = prompt_config
        
        from .values import defaultai as values
        if use_public_information:
            messages = values.use_public_information_messages
            messages[-1]["content"] = history[-1]["user"]
            completion = openai.ChatCompletion.create(
            engine=self.chatgpt_deployment,
            messages=messages,
            temperature=0.0)
            return {"data_points": [], "answer": completion.choices[0].message.content , "thoughts": ""}
            
        else: 
           prompt = history[-1]["user"]
           messages = values.no_public_information_messages
           messages[-1]["content"] = history[-1]["user"]
           completion = openai.ChatCompletion.create(
            engine=self.chatgpt_deployment,
            messages=messages,
        temperature=0.0
    )          
        
        output = completion.choices[0].message.content
        logging.info("responsee")
        logging.info(output)
        
        if any([item in output for item in values.irrelevant_list]):
            return {"data_points": [], "answer": output, "thoughts": ""}
        
        
        logging.info("inside custom function")
        use_semantic_ranker = True if overrides.get("semantic_ranker") else False
        use_semantic_captions = True if overrides.get("semantic_captions") else False
        top = overrides.get("#top") or 3
        exclude_category = overrides.get("exclude_category") or None
        filter = "category ne '{}'".format(exclude_category.replace("'", "''")) if exclude_category else None

        # STEP 1: Generate an optimized keyword search query based on the chat history and the last question
        prompt = values.query_prompt_template.format(chat_history=self.get_chat_history_as_text(history, include_last_turn=False), question=history[-1]["user"])
        completion = openai.Completion.create(
            engine=self.gpt_deployment, 
            prompt=prompt, 
            temperature=0.0, 
            max_tokens=32, 
            n=1, 
            stop=["\n"])
        q = completion.choices[0].text
        logging.info("got q")
        print("q:",q)
        print("use_semantic_ranker", use_semantic_ranker)
        # STEP 2: Retrieve relevant documents from the search index with the GPT optimized query
        if use_semantic_ranker:
            r = self.search_client.search(q, 
                                          filter=filter,
                                          query_type=QueryType.SEMANTIC, 
                                          query_language="en-us", 
                                          query_speller="lexicon", 
                                          semantic_configuration_name="default", 
                                          top=top, 
                                          query_caption="extractive|highlight-false" if use_semantic_captions else None)
        else:
            r = self.search_client.search(q, filter=filter, top=top)

        print("r:", r)
        print("use_semantic_captions:", use_semantic_captions)
        print("self.content_field:", self.content_field)

        if use_semantic_captions:
            results = [doc[self.sourcepage_field] + ": " + nonewlines(" . ".join([c.text for c in doc['@search.captions']])) for doc in r]
        else:
            results = [doc[self.sourcepage_field] + ": " + nonewlines(doc[self.content_field]) for doc in r]
        
        print("Results:", results)

        content = "\n".join(results)
        print("content:", content)
        logging.info("got content")

        follow_up_questions_prompt = values.follow_up_questions_prompt_content if overrides.get("suggest_followup_questions") else ""
        
        # Allow client to replace the entire prompt, or to inject into the exiting prompt using >>>
        prompt_override = overrides.get("prompt_template")
        if prompt_override is None:
            prompt = values.prompt_prefix.format(injected_prompt="", sources=content, chat_history=self.get_chat_history_as_text(history), follow_up_questions_prompt=follow_up_questions_prompt)
        elif prompt_override.startswith(">>>"):
            prompt = values.prompt_prefix.format(injected_prompt=prompt_override[3:] + "\n", sources=content, chat_history=self.get_chat_history_as_text(history), follow_up_questions_prompt=follow_up_questions_prompt)
        else:
            prompt = prompt_override.format(sources=content, chat_history=self.get_chat_history_as_text(history), follow_up_questions_prompt=follow_up_questions_prompt)

        # STEP 3: Generate a contextual and content specific answer using the search results and chat history
        completion = openai.Completion.create(
            engine=self.chatgpt_deployment, 
            prompt=prompt, 
            temperature=0.0, 
            max_tokens=1024, 
            n=1, 
            stop=["<|im_end|>", "<|im_start|>"])
        logging.info("got results")
        return {"data_points": results, "answer": completion.choices[0].text, "thoughts": f"Searched for:<br>{q}<br><br>Prompt:<br>" + prompt.replace('\n', '<br>')}
    
    def get_chat_history_as_text(self, history, include_last_turn=True, approx_max_tokens=1000) -> str:
        history_text = ""
        for h in reversed(history if include_last_turn else history[:-1]):
            history_text = """<|im_start|>user""" +"\n" + h["user"] + "\n" + """<|im_end|>""" + "\n" + """<|im_start|>assistant""" + "\n" + (h.get("bot") + """<|im_end|>""" if h.get("bot") else "") + "\n" + history_text
            if len(history_text) > approx_max_tokens*4:
                break    
        return history_text