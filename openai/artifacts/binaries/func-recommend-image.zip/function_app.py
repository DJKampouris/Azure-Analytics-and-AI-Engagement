import requests
import json
from PIL import Image
import openai
import os
import random
import requests
import os
import azure.ai.vision as visionsdk
import time
from collections import defaultdict
import io
import concurrent.futures
import azure.functions as func
import logging
from azure.storage.blob import BlobServiceClient, ContentSettings
from io import BytesIO
import string 
import os
from requests.exceptions import RequestException
import asyncio

app = func.FunctionApp()

# API_KEY = ""
# # Define the connection string and blob container name
# connect_str = ""
container_name = os.environ.get("container_name") or "data2"
AZURE_OPENAI_KEY = os.environ.get("OPENAI_API_KEY") or "#AZURE_OPENAI_KEY#"
AZURE_COGNITIVE_KEY = os.environ.get("cognitive_key") or "#AZURE_COGNITIVE_KEY#"
AZURE_OPENAI_type = os.environ.get("openai_api_type") or "azure"
AZURE_OPENAI_BASE = os.environ.get("OPENAI_API_ENDPOINT") or "#OPENAI_ENDPOINT#"
openai.api_version = "2023-03-15-preview"
ENGINE = os.environ.get("ENGINE") or "gpt-35-turbo"
STORAGE_ACCOUNT = os.environ.get("STORAGE_ACCOUNT") or "#STORAGE_ACCOUNT_NAME#"
connect_str_key = os.environ.get("connect_str") or "#STORAGE_CONNECTION_STRING#"
STORAGE_CONTAINER = os.environ.get("STORAGE_CONTAINER") or "vouquahyaeyiepo"
STORAGE_ACCOUNT_KEY = os.environ.get("STORAGE_ACCOUNT_KEY") or "#STORAGE_ACCOUNT_KEY#"
COGNITIVE_SERVICE_API = os.environ.get("COGNITIVE_SERVICE_API") or "#COGNITIVE_SERVICE_ENDPOINT#"

def get_param(req, param_name, default_value=None):
    param_value = req.params.get(param_name)

    if not param_value:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            param_value = req_body.get(param_name)

    return param_value or default_value

def handle_request_exception(e, error_message):
    if hasattr(e, 'response') and e.response is not None:
        return func.HttpResponse(body=error_message, status_code=e.response.status_code)
    else:
        return func.HttpResponse(body=error_message, status_code=500)

def process_image(req):
    
    req_body = req.get_json()
    image_url = req_body["image_url"] 
    
    
    if image_url is None:
        image = req.files['image']
        return image.read()
    return image_url

def process_size(req):
    return get_param(req, 'size', 512)

def process_image_num(req):
    return get_param(req, 'image_num', '1')

def remove_background(image_url):
    try:
        return background_removal(image_url)
    except RequestException as e:
        return handle_request_exception(e, "An error occurred while removing the background")

def extract_main_color(removal):
    try:
        return get_colors(removal)
    except RequestException as e:
        return handle_request_exception(e, "An error occurred while extracting the main color")

def extract_color_name(main_color):
    try:
        return get_color_name(main_color)
    except RequestException as e:
        return handle_request_exception(e, "An error occurred while extracting the color name")

def extract_dominant_color(color_name):
    try:
        return get_dominant_color(color_name)
    except RequestException as e:
        return handle_request_exception(e, "An error occurred while extracting the dominant color name")

def extract_caption(image_url):
    try:
        return generate_caption(image_url)
    except RequestException as e:
        return handle_request_exception(e, "An error occurred while extracting the caption")

def generate_image(prompt, scenario_num):
    try:
        return generate(prompt, scenario_num)
    except RequestException as e:
        return handle_request_exception(e, "An error occurred while generating the image from prompt")

def compose_images(removal, result, size, image_num):
    executor = concurrent.futures.ThreadPoolExecutor()
    compose_func = compose_image_abstract if image_num == '3' else compose_image
    return list(executor.map(lambda url: (logging.info(compose_func(removal, url, size)), compose_func(removal, url, size)), result))

def upload_to_blob(removal):
    with BytesIO(removal) as output:
        im = Image.open(output)
        with BytesIO() as png_output:
            im.save(png_output, format='PNG')
            png_data = png_output.getvalue()

    blob_service_client = BlobServiceClient.from_connection_string(connect_str_key)
    random_string = ''.join(random.choices(string.ascii_lowercase + string.digits, k=7))
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=f"{random_string}.jpg")
    content_settings = ContentSettings(content_type="image/jpeg")
    blob_client.upload_blob(png_data, overwrite=True, content_settings=content_settings)
    return blob_client.url

def generate_caption_string(caption_data):
    vals = caption_data['denseCaptionsResult']['values']
    captions = {values['text']: values['confidence'] for values in vals}
    temp = {val: key for key, val in captions.items()}
    res = {val: key for key, val in temp.items()}
    return '\n'.join([f"{i+1}. {cpt.capitalize()}." for i, cpt in enumerate(res)])


def generate_response_data(removal, main_color, dominant_color_name, color_name, text, caption, prompt, compose_urls, image_num):
    data = {
        "productDescription": "a pink and purple fabric",
        "recommendedItems": {},
        "background_removed_image": upload_to_blob(removal),
        "major color": dominant_color_name,
        "colors": color_name,
        "caption": generate_caption_string(caption),
        "summary of caption": text,
        "prompt": prompt
    }

    for i, url in enumerate(compose_urls):
        data["recommendedItems"][f"Recommended Item {i+1}"] = url[1]

    return data

@app.function_name(name="recommendFromImage_V2")
@app.route(route="recommendFromImage_V2",auth_level=func.AuthLevel.ANONYMOUS)
def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    try:
        image_data = process_image(req)
        size = process_size(req)
        image_num = process_image_num(req)

        if not image_data:
            return func.HttpResponse("Please provide a image_url on the query string or binary image in the request body", status_code=400)

        start_time = time.time()
        removal = remove_background(image_data)
        b_removal_time = time.time()
        logging.info(f"Background removal took {b_removal_time - start_time} seconds")

        main_color = extract_main_color(removal)
        m_color_time = time.time()
        logging.info(f"get_colors took {m_color_time - b_removal_time} seconds")

        color_name = extract_color_name(main_color)
        t_color_name = time.time()
        logging.info(f"get_color_name took {t_color_name - m_color_time} seconds")

        dominant_color_name = extract_dominant_color(color_name)
        logging.info('color_name generated')

        text, caption = extract_caption(image_data)
        t_caption_time = time.time()
        logging.info(f"Caption generation took {t_caption_time - t_color_name} seconds")

        prompt = dalle_prompt_real(text, image_num)
        logging.info('prompt generated')

        result = generate_image(prompt, image_num)
        t_image_generate = time.time()
        logging.info(f"Image generation took {t_image_generate - t_caption_time} seconds")
        try:
            logging.info(f"Generated images:{result}")
            compose_urls = compose_images(removal, result, size, image_num)
        except Exception as e:
            if isinstance(e, RequestException):
                logging.info(f"An error occurred while composing the images: {str(e)}")
                return handle_request_exception(e, "An error occurred while composing the images")
            else:
                logging.info(f"An error occurred while composing the images: {str(e)}")
                return func.HttpResponse(body="An error occurred while composing the images", status_code=500)
        t_compose_url = time.time()
        logging.info(f"Compose url took {t_compose_url - t_image_generate} seconds")
        try:
            response_data = generate_response_data(removal, main_color, dominant_color_name, color_name, text, caption, prompt, compose_urls, image_num)
            json_data = json.dumps(response_data)
            return func.HttpResponse(json_data, status_code=200, mimetype="application/json")
        except Exception as e:
            logging.error(f"An error occurred while generating the response data: {str(e)}")
            handle_request_exception(e, "An error occurred while generating the response data")
            
    except requests.exceptions.RequestException as e:
        if isinstance(e, RequestException):
            return handle_request_exception(e, "An error occurred while processing the request")
        else:
            return func.HttpResponse(body="An error occurred while processing the request", status_code=500)


    

def get_dominant_color(color_name):
    items = color_name.split(" ")
    dominant_color_name = items[0]
    return dominant_color_name

# Remove background from Image

def background_removal(image_url):
    # url = "https://eastus.cognitiveservices.azure.com/computervision/imageanalysis:segment?api-version=2023-02-01-preview&mode=backgroundRemoval"
    url = f"{COGNITIVE_SERVICE_API}computervision/imageanalysis:segment?api-version=2023-02-01-preview&mode=backgroundRemoval"
    
    payload = json.dumps({
    "url": image_url
    })
    headers = {
    'Content-Type': 'application/json',
    'Ocp-Apim-Subscription-Key': AZURE_COGNITIVE_KEY
    }
    
    try:
        response = requests.request("POST", url, headers=headers, data=payload)
        response.raise_for_status
        removal = response.content
        return removal
    except requests.exceptions.RequestException as e:
        error_message = f"An error occurred while removing the background: {str(e)}"
        logging.error(error_message)
        raise e

def get_colors(removal):
# Create a file object from the image bytes
    image_file = io.BytesIO(removal)

    # Open the image file
    image = Image.open(image_file)

    # Resize the image to a smaller size for faster processing
    image = image.resize((100, 100))

    # Get the colors of all pixels in the image
    pixel_colors = list(image.getdata())

    # Count the frequency of each color
    color_counts = defaultdict(int)
    for color in pixel_colors:
        color_counts[color] += 1


    # Define a threshold for merging similar colors
    threshold = 80

    # Create a new dictionary to hold merged color counts
    merged_counts = defaultdict(int)

    # Merge similar colors
    for color, count in color_counts.items():
        for merged_color, merged_count in merged_counts.items():
            if abs(color[0]-merged_color[0]) < threshold and \
            abs(color[1]-merged_color[1]) < threshold and \
            abs(color[2]-merged_color[2]) < threshold:
                # Merge the counts
                merged_counts[merged_color] += count
                break
        else:
            # If no similar color was found, add the color to the merged counts
            merged_counts[color] += count

    #recude black color to 1/10
    # Access the count of (0, 0, 0, 0) in the merged_counts dictionary
    count = merged_counts[(0, 0, 0, 0)]

    # Divide the count by 10 and round it to the nearest integer
    new_count = round(count / 10)

    # Update the count of (0, 0, 0, 0) in the merged_counts dictionary
    merged_counts[(0, 0, 0, 0)] = new_count

    # Sort the merged colors by frequency
    sorted_merged = sorted(merged_counts.items(), key=lambda x: x[1], reverse=True)

    main_color = []
    # Print the most common merged colors
    for color, count in sorted_merged[:3]:
        
        main_color.append(color)
    main_color_rgb = [(r, g, b) for r, g, b, a in main_color]

    # Convert each RGB tuple to its corresponding hexcode
    main_color_hex = ['#' + ''.join(f"{c:02x}" for c in rgb) for rgb in main_color_rgb]

    return main_color_hex

def get_color_name(main_color):
    openai.api_type = AZURE_OPENAI_type
    openai.api_base = AZURE_OPENAI_BASE
    openai.api_version = "2023-03-15-preview"
    openai.api_key = AZURE_OPENAI_KEY
    try:
        response = openai.ChatCompletion.create(
        engine=ENGINE, 
        messages=[
            {"role": "system", "content": "You are the AI assistant who extract information from data"},
            {"role": "user", "content": f"can you give me all the color names from this hexcode data? {main_color}. strictly do not include anything on your response exacept color names. your response format will be 'color1, color2, color3,..."}
        ])

        text = response['choices'][0]['message']['content']
        return text
    except requests.exceptions.RequestException as e:
        error_message = f"An error occurred while extracting the color name: {str(e)}"
        logging.error(error_message)
        raise e
    
def dalle_prompt_real(text,image_num):
    openai.api_type = AZURE_OPENAI_type
    openai.api_base = AZURE_OPENAI_BASE
    openai.api_version = "2023-03-15-preview"
    openai.api_key = AZURE_OPENAI_KEY

    if image_num == '1':
        return "Generate a digital artwork with a plain gradient background that seamlessly blends sea green and sky blue colors, complementing a central element with a reflective or metallic appearance"
    if image_num == '2':
        return "Generate background using these colors #57969A #B0D3D8 inspired by the starry night, cafe terrace at night, irises and impression sunrise"
    if image_num == '3':
        return "Generate a realistic image of a convertible orange sports car on a road in a sunny day"
    
def dalle_prompt_abstract(image_num):
    if image_num == '1':
        return "Generate a light feel abstract image using the colors which are complement to aqua and sea green. Ensure main color is complement to aqua. Contain merged boxes or abstract art"
    elif image_num == '2':
        return "Generate a light feel abstract image using the colors light maroon and pink. Ensure main color is pink. Contain merged boxes or abstract art"
    elif image_num == '3':
        return "Generate a light feel abstract image using the colors red and black. Ensure main color is red. Contain merged boxes or abstract art"
    elif image_num == '4':
        return "Generate a light feel abstract image using the colors orange and black. Ensure main color is orange. Contain merged boxes or abstract art"

def get_image(text):
    openai.api_type = AZURE_OPENAI_type
    openai.api_key = AZURE_OPENAI_KEY
    openai.api_base = AZURE_OPENAI_BASE
    api_base = AZURE_OPENAI_BASE
    api_key = AZURE_OPENAI_KEY
    api_version = '2022-08-03-preview'

    url = "{}dalle/text-to-image?api-version={}".format(api_base, api_version)
    headers = {"api-key": api_key, "Content-Type": "application/json"}
    body = {
        "caption": text,
        "resolution": "512x512"
    }
    
    # get max_tries from the environment_variable or default to 10
    max_tries = os.getenv("MAX_TRIES", 5)
    tries = 0
    total_wait = os.getenv("TOTAL_WAIT", 25)
    logging.info(f"total_wait: {total_wait}, max_tries: {max_tries}")

    while tries < max_tries:
        submission = requests.post(url, headers=headers, json=body)
        if submission.status_code != 202:
            retry_after = int(submission.headers.get('Retry-After', 0))
            time.sleep(retry_after+1)
            continue
        else:
            try:
                operation_location = submission.headers['Operation-Location']
            except KeyError:
                logging.info("failed: Operation-Location header missing!!!")
                time.sleep(2)
                tries += 1
                continue
            
            start_time = time.time()
            while time.time() - start_time < total_wait:
                response = requests.get(operation_location, headers=headers)
                if response.status_code == 200:
                    status = response.json()['status']
                    if status == "Succeeded":
                        logging.info("succeeded...")
                        return response.json()['result']['contentUrl']
                    elif status == "Running":
                        retry_after = int(response.headers.get('Retry-After', 0))
                        time.sleep(retry_after+1)
                    else:
                        logging.info("failed: status = " + status)
                        break
                else:
                    logging.info("failed: response code = " + str(response.status_code))
                    time.sleep(4)
                    break
            tries += 1
    else:
        return None

# construct url list from scenario_num and index list

def get_url_list(index_list,num=1):

    url_list = []
    for i in index_list:
        url_list.append(f"https://{STORAGE_ACCOUNT}.blob.core.windows.net/{STORAGE_CONTAINER}/scenario{num}/image{i}.png")
        logging.info(url_list)
    return url_list

def generate(text2, scenario_num):
    image_list = list(range(1, 26))
    dalle_image = get_image(text2)
    
    # since we are using scenario4 folder for scenario, we need to change scenario_num to 4
    if scenario_num == '3': scenario_num = '4'
    if dalle_image is None:
        # choose from 4 numbers from 25 integers and give it in the list
        index_list = random.sample(image_list, 4)
        total_image_list =  get_url_list(index_list,scenario_num)
    else:
       index_list = random.sample(image_list, 3)
       dalle_list = [dalle_image]
       logging.info(dalle_list)
       additional_image_list = get_url_list(index_list,scenario_num)
       total_image_list = dalle_list + (additional_image_list)
       
    logging.info(f"total_image_list:{total_image_list}")   
    return total_image_list
        
        
    


# Get caption from
def generate_caption(image_url):
    openai.api_type = AZURE_OPENAI_type
    openai.api_base = AZURE_OPENAI_BASE
    openai.api_version = "2023-03-15-preview"
    openai.api_key = AZURE_OPENAI_KEY 

    your_endpoint = COGNITIVE_SERVICE_API
    your_key = AZURE_COGNITIVE_KEY
    service_options = visionsdk.VisionServiceOptions(your_endpoint, your_key)
    vision_source = visionsdk.VisionSource(url=image_url)
    image_analysis_options = visionsdk.ImageAnalysisOptions()
    image_analysis_options.features = (
        visionsdk.ImageAnalysisFeature.DENSE_CAPTIONS
    )
    image_analysis_options.language = 'en'
    image_analyzer = visionsdk.ImageAnalyzer(
        service_options, vision_source, image_analysis_options)
    result = image_analyzer.analyze()
    response = {}
    response_json={}
    if result.reason == visionsdk.ImageAnalysisResultReason.ANALYZED:
        if result.caption is not None:
            image_caption = result.caption.content
        else:
            image_caption = ''
        result_details = visionsdk.ImageAnalysisResultDetails.from_result(
            result)
        response_json = json.loads(result_details.json_result)
        response = openai.ChatCompletion.create(
            engine=ENGINE,
            messages=[
                {"role": "system", "content": "you are the AI assistant who extract main products of data"},
                {"role": "user", "content": f"can you give me what products are in this data? Just return the items having probability of more than 40 percent. {response_json} "}
            ])
    else:
        logging.info('Azure vision failed to generate dense caption of this image')
    formatted_result = response['choices'][0]['message']['content']
    return formatted_result, response_json

# Get compose image from dalle and background removal
def compose_image_abstract(removal, dalle_url, size):
    return dalle_url

# Get compose image from dalle and background removal
def compose_image(removal, dalle_url, size):
    image_file = io.BytesIO(removal)
    front_img = Image.open(image_file)

    response = requests.get(dalle_url)
    back_img = Image.open(BytesIO(response.content))

    # Resize the front image while maintaining its aspect ratio
    front_img.thumbnail((size,size))

    # Find the size of the larger image
    width = max(front_img.width, back_img.width)
    height = max(front_img.height, back_img.height)

    # Create a new empty image with the size of the larger image
    composed_img = Image.new("RGBA", (width, height))

    # Paste the back image onto the composed image with an offset
    back_offset = ((width - back_img.width) // 2, (height - back_img.height) // 2)
    composed_img.paste(back_img, back_offset)

    # Paste the front image onto the composed image with an offset
    front_offset = ((width - front_img.width) // 2, (height - front_img.height) // 2)
    composed_img.paste(front_img, front_offset, front_img)

    # Create a buffer for the image data
    buf = BytesIO()

    # Save the image data to the buffer in PNG format
    composed_img.save(buf, format='PNG')

    # Get the binary representation of the image data
    binary = buf.getvalue()

    # connect_str = "DefaultEndpointsProtocol=https;AccountName=retailcontosoclothing;AccountKey=VxS15O/wK8ChhYqc98fTPUuvarsosYumDND83IQufXh2j168ExcWnmYJvPyYyNkifWlehyg7gA9z+AStSxNAAg==;EndpointSuffix=core.windows.net"
    connect_str = connect_str_key
    # container_name = "data2"
    # Create a BlobServiceClient object using the connection string
    blob_service_client = BlobServiceClient.from_connection_string(connect_str)

    alphabet_digits = string.ascii_lowercase + string.digits 
    random_string = ''.join(random.choices(alphabet_digits, k=7))
    # Upload the PNG data to Azure Blob Storage

    blob_client = blob_service_client.get_blob_client(container=container_name, blob=f"{random_string}.jpg")
    content_settings = ContentSettings(content_type="image/jpeg")

    blob_client.upload_blob(binary, overwrite=True, content_settings = content_settings)
    blob_url = blob_client.url


    return blob_url