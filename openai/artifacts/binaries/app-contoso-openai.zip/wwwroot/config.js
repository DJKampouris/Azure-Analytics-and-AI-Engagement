window.config = {
  BlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/openai/",
  IconBlobBaseUrl:
    "https://#STORAGE_ACCOUNT#.blob.core.windows.net/openai/left-nav-icons/",

  APIUrl: "https://#SERVER_NAME#.azurewebsites.net",
  // APIUrl: "https://localhost:5001",

  WorldMapReportID: "#World Map OpenAI#",
  WorldMapReportSectionName: "ReportSection0ad994d60f2f36edfe34",

  CEODashboardBeforeID: "",
  CEODashboardBeforeReportID: "#Retail Group CEO KPI OpenAI#",
  CEODashboardBeforeReportSectionName: "ReportSection5f752c6bde03670c8284",

  CEODashboardAfterID: "",
  CEODashboardAfterReportID: "#Retail Group CEO KPI OpenAI#",
  CEODashboardAfterReportSectionName: "ReportSection68cb8066934630a72b53",

  CallCenterSummaryBeforeReportID: "#GM Call Center Report Before OpenAI#",
  CallCenterSummaryBeforeReportSectionName: "ReportSectionda209890a7f0f9e42736",

  CallCenterScriptBeforeReportID: "#GM Call Center Report Before OpenAI#",
  CallCenterScriptBeforeReportSectionName: "ReportSection623b64746831c0065bc0",

  CallCenterSummaryAfterReportID: "#GM Call Center Report After OpenAI#",
  CallCenterSummaryAfterReportSectionName: "ReportSectionda209890a7f0f9e42736",

  CallCenterScriptAfterReportID: "#GM Call Center Report After OpenAI#",
  CallCenterScriptAfterReportSectionName: "ReportSection623b64746831c0065bc0",

  id: 52,
  industryId: 1,
  preFillCredentials: true,
  userName: "spencer@contoso.com",
  password: "M1cr050ft#1!",
  title: "Contoso",
  logoImageURL:
    "https://#STORAGE_ACCOUNT#.blob.core.windows.net/openai/New_Contoso/top_left_logo_CONTOSO.png",
  backgroundImageURL:
    "https://#STORAGE_ACCOUNT#.blob.core.windows.net/openai/contoso_background.png",
  backgroundColor: null,
  primaryColor: "rgba(0, 161, 203, 1)",
  secondaryColor: "rgba(0, 75, 118, 1)",
  headerImageUrl:
    "https://#STORAGE_ACCOUNT#.blob.core.windows.net/openai/contoso_top_level_header_bg.png",
  headerBgColor: null,
  navImageUrl:
    "https://#STORAGE_ACCOUNT#.blob.core.windows.net/openai/contoso_left_nav_bg.png",
  navColor: null,
  isFavorite: false,
  description: "Ask me something",
  subTitle: "Contoso",
  color: null,
  isEnabled: true,

  documents: [],
  campaigns: [],
  prompt1:
    "How can we ensure AI systems align with human values and ethical principles?",
  prompt2:
    "What are some ways to implement AI systems that encourage openness and responsibility?",
  prompt3: "How can we ensure AI technologies are accessible and inclusive?",
  questionPlaceHolder:
    "How can we ensure AI systems align with human values and ethical principles?",
  loginBoxImage:
    "https://#STORAGE_ACCOUNT#.blob.core.windows.net/openai/New_Contoso/CONTOSO_login_visual.png",
  loginBackground:
    "https://#STORAGE_ACCOUNT#.blob.core.windows.net/openai/contoso_login_page_background.png",
  loginBackgroundColor: "",
  loginTextBoxImage:
    "https://#STORAGE_ACCOUNT#.blob.core.windows.net/openai/contoso_login_text_box.png",
  disableTitle: true,
  navBarPrimaryColor: "rgba(0, 75, 118, 1)",
  navBarSecondaryColor: "rgba(0, 161, 203, 1)",
  navBarTextColor: "rgba(255, 255, 255, 1)",
  tabPrimaryColor: "rgba(0, 161, 203, 1)",
  tabSecondaryColor: "rgba(0, 75, 118, 1)",
  dropdownPrimaryColor: "rgba(0, 161, 203, 1)",
  dropdownSecondaryColor: "rgba(0, 75, 118, 1)",
  scrollBarPrimaryColor: "rgba(255, 255, 255, 0.5)",
  scrollBarSecondaryColor: "rgba(255, 255, 255, 0.5)",

  dropdownTextColor: null,
  tabTextColor: "rgba(255, 255, 255, 1)",
  chatApproach: "",
  chatCompany: "",
  callCenterVideoURL:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/51fed8da-76d8-4ec2-bcdb-1860430b0fda/ManuFacturing_CallCenter.ism/manifest(format=m3u8-cmaf)",
  callCenterScript:
    "Mina:  Thank you for calling Assistance. This is Mina Jones, how may I assist you? \r\nBrent:  Hi, I need road assistance for my truck. I’m having clutch problems while changing gears.  \r\nMina:  Okay. What is your vehicle identification number? Also do you have any warranty or service plan coverage that you are aware of?  \r\nBrent: My VIN is 9283498493. Yes, I have the standard warranty and the extended service plan. \r\nMina:  I see. Are you in a safe place? Do you need any medical assistance?  \r\nBrent: No, I'm fine. I pulled over to the shoulder of the road and turned on my hazard lights. So I should be good \r\nMina:  Good. Please stay inside your truck and keep your seat belt on until help arrives. I'll check our network of dealers and service providers near your location and find the best option for you. Please stay on the line while I do that. \r\nMina:  Brent, are you still there? \r\nBrent: Yes, I'm here. \r\nMina:  Excellent. I've found a nearby Contoso dealer who can send a repair truck to your location within an hour. They will also tow your truck to their shop if needed. Please provide them with your fault code 61 if they ask.   \r\nBrent: Thank you so much, Mina. You're a lifesaver. \r\nMina:  You're very welcome, Brent. Is there anything else I can do to help you? \r\nBrent: No, thanks.  \r\nMina: Wonderful. Please stay safe and have a great day.",
  callCenterCustomerImage: "customer_gm.png",
  callCenterBackendImage: "backend_gm.png",
  callCenterAgentImage: "agent_gm.png",
  callCenterExtractFromConversationWithKey:
    "Extract the following information from the conversation below:   \r\n\r\nCall reason (key: reason)  \r\nCaller name (key: caller_name)  \r\nAgent Name (key: agent_name)  \r\nTruck location (key: location)  \r\nVin (key: VIN)  \r\nCaller sentiment (key: caller_sentiment)  \r\nFault code (key: fault_code)  \r\nA short, yet detailed summary (key: summary)  \r\n\r\nPlease answer in JSON machine-readable format, using the keys from above. Format the output as a JSON object called “results”. Pretty print the JSON and make sure that it is properly closed at the end.  ",
  callCenterExtractFromConversationWithoutKey:
    "Generate a summary of the conversation in the following format with proper numbering: \r\n\r\n1. Main reason for the conversation. \r\n2. Sentiment of the customer.\r\n3. How did the agent handle the conversation?   \r\n4. What was the final outcome of the conversation?   \r\n5. Did the agent help with getting the fault code?  \r\n6. List the troubleshooting instructions that the agent offered?  \r\n7. Create a short summary of the conversation.",
  showSettings: true,
  chatContainerBackgroundColor: "rgba(0, 75, 118, 1)",
  isSampleDemo: null,
  landingPageImage:
    "https://#STORAGE_ACCOUNT#.blob.core.windows.net/openai/New_Contoso/landing_page_visual.png",
  indexName: null,
  containerName: null,
  order: 0,

  finaleVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/832c6447-b1fd-4e50-b711-8f4590f19f79/OpenAI_DreamDemo_Finale_V02.ism/manifest",
};
