import logging      
import azure.functions as func      
from azure.search.documents.indexes import SearchIndexClient      
from azure.core.credentials import AzureKeyCredential      
from azure.storage.blob import BlobServiceClient      
import json      
import time      
import datetime    
import os

search_service_name = os.environ.get("SEARCH_SERVICE_NAME")
search_service_key = os.environ.get("SEARCH_SERVICE_KEY")
storage_account_key = os.environ.get("STORAGE_ACCOUNT_KEY")
storage_account_name = os.environ.get("STORAGE_ACCOUNT_NAME")
form_recognizer_key = os.environ.get("FORM_RECOGNIZER_KEY")

search_creds = AzureKeyCredential(search_service_key)      
index_list = ['finance', 'gm-demo','gm-demo-test','gptkbindex','healthcare','ralph-lauren','ralph-lauren-v2','retail']      
      
def deleteAll(req: func.HttpRequest) -> func.HttpResponse:      
    logging.info('Python HTTP trigger function processed a request.')      
    index_client = SearchIndexClient(endpoint=f"https://{search_service_name}.search.windows.net",      
                                     credential=search_creds)      
    blob_service = BlobServiceClient(      
        account_url=f"https://{storage_account_name}.blob.core.windows.net",      
        credential=storage_account_key      
    )      
      
    deleted_containers = 0  
    deleted_indexes = 0  
    now_time = datetime.datetime.now()    


    for index_name in index_client.list_index_names():   
        try:
            if '-' in index_name:
                logging.info(index_name)
                index_ = index_name.split('-')[1]
                index_time = int(index_)
                if index_ not in index_list:
                    logging.info(index_)  
                    
                
                    created_time = datetime.datetime.fromtimestamp(index_time/1000)    
                    time_diff = now_time - created_time    
                    if time_diff.total_seconds()/3600 >= 1:    
                
                        index_client.delete_index(index_name)    
                        deleted_indexes += 1   
        except Exception as e:  
            continue 
      
    for container in blob_service.list_containers():   
        try:
            if '-' in container.name:
                logging.info(container.name)
                container_ = container.name.split('-')[1]
                container_time = int(container_)
                if container_ not in index_list:
                    logging.info(container_) 
                    created_time = datetime.datetime.fromtimestamp(container_time/1000)    
                    time_diff = now_time - created_time    
                    if time_diff.total_seconds()/3600 >= 1:    
                        blob_service.delete_container(container.name)    
                        deleted_containers += 1   
                        logging.info('Deleted container %s', container.name) 
        except Exception as e:  
            continue  
           
      
    
         
        
      
    response_data = {      
        "deleted_containers": deleted_containers,      
        "deleted_indexes": deleted_indexes      
    }      
    # response = func.HttpResponse(json.dumps(response_data))      
    # response.headers['Content-Type'] = 'application/json'      
    return response_data