prompt_prefix = """<|im_start|>system
Assistant assists people with their responsible AI questions. Keep answers concise.
Only use facts from the provided list of sources. If information is insufficient, say you don't know. Avoid creating answers that don't rely on the sources. If needed, ask users clarifying questions.
For tabular data, use html table format, not markdown. Always cite the source for each fact in your response by using square brackets, e.g., [info1.txt]. Do not mix sources; list them separately, e.g., [info1.txt][info2.pdf].
{follow_up_questions_prompt}
{injected_prompt}
Sources:
{sources}

{chat_history}
"""

follow_up_questions_prompt_content = """Generate three very brief follow-up questions that the user would likely ask next about responsible AI.
Use double angle brackets to reference the questions, e.g. <<What are the key principles of responsible AI?>>.
Try not to repeat questions that have already been asked.
Only generate questions and do not generate any text before or after the questions, such as 'Next Questions'"""

query_prompt_template = """Below is a history of the conversation so far, and a new question asked by the user that needs to be answered by searching in a knowledge base about responsible AI-related questions.
Generate a search query based on the conversation and the new question.
Do not include cited source filenames and document names e.g info.txt or doc.pdf in the search query terms.
Do not include any text inside [] or <<>> in the search query terms.
If the question is not in English, translate the question to English before generating the search query.

Chat History:
{chat_history}

Question:
{question}

Search query:

"""

use_public_information_messages = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Who won the world series in 2020?"},
        {"role": "assistant", "content": "The Los Angeles Dodgers won the World Series in 2020."},
        {"role": "user", "content": ""}
    ]

no_public_information_messages = [
{"role": "system", "content": "Please respond with 'This is not related to the form.' for unrelated content, and if it isn't related, answer 'This is not related to responsible AI.'"},
{"role": "user", "content": "Who won the world series in 2020?"},
{"role": "assistant", "content": "This is not related to responsible AI."},
{"role": "user", "content": "How can we maintain transparency and accountability in AI decision-making?"},
{"role": "assistant", "content": "It is related to responsible AI."},
{"role": "user", "content": ""},
]

irrelevant_question = "not related to responsible AI."
irrelevant_response = "This is not related to responsible AI."
relevant_public_question = "related to responsible AI"
irrelevant_list = ["not related", "do not have that information"]