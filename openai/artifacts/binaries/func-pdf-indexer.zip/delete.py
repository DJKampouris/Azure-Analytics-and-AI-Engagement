import logging
import azure.functions as func
from azure.search.documents.indexes import SearchIndexClient
from azure.core.credentials import AzureKeyCredential
from azure.storage.blob import BlobServiceClient
import json
import os


search_service_name = os.environ.get("SEARCH_SERVICE_NAME") or "#SEARCH_SERVICE_NAME#"
search_service_key = os.environ.get("SEARCH_SERVICE_KEY") or "#SEARCH_SERVICE_KEY#"
storage_account_key = os.environ.get("STORAGE_ACCOUNT_KEY") or "#STORAGE_ACCOUNT_KEY#"
storage_account_name = os.environ.get("STORAGE_ACCOUNT_NAME") or "#STORAGE_ACCOUNT_NAME#"
form_recognizer_key = os.environ.get("FORM_RECOGNIZER_KEY") or "#FORM_RECOGNIZER_KEY#"
search_creds = AzureKeyCredential(search_service_key)
index_list = ['finance', 'gm-demo','gm-demo-test','gptkbindex','healthcare','ralph-lauren','ralph-lauren-v2','retail']

def delete(index,container):
    logging.info('Python HTTP trigger function processed a request.')
    # req_body = req.get_json()
    # index_name = req_body['index_name']
    # container_name = req_body['container_name']
    index_name = index
    container_name = container

    if not index_name:
        return func.HttpResponse(
            "Please pass the indexname parameter in the request",
            status_code=400
        )

    index_client = SearchIndexClient(endpoint=f"https://{search_service_name}.search.windows.net",
                                     credential=search_creds)
    blob_service = BlobServiceClient(
        account_url=f"https://{storage_account_name}.blob.core.windows.net",
        credential=storage_account_key
    )

    # container_name = "content"
    blob_container = blob_service.get_container_client(container_name)

    index_deleted = False
    container_deleted = False
 
    if blob_container.exists() and container_name not in index_list:
        blob_container.delete_container()
        logging.info('Deleted container %s', container_name)
        container_deleted = True
    else:
        logging.warning('Container %s does not exist.', container_name)

    if index_name in index_client.list_index_names() and index_name not in index_list:
        index_client.delete_index(index_name)
        index_deleted = True

    response_data = {
        "container_deleted": container_deleted,
        "index_deleted": index_deleted
    }
    # response = func.HttpResponse(json.dumps(response_data))
    # response.headers['Content-Type'] = 'application/json'
    return response_data



