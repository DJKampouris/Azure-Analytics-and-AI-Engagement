import os
import mimetypes
import logging
import openai
import azure.functions as func
from azure.identity import DefaultAzureCredential
from azure.search.documents import SearchClient
from approaches.retrievethenread import RetrieveThenReadApproach
from approaches.readretrieveread import ReadRetrieveReadApproach
from approaches.readdecomposeask import ReadDecomposeAsk
from approaches.chatreadretrieveread import ChatReadRetrieveReadApproach
from azure.storage.blob import BlobServiceClient
from azure.core.credentials import AzureKeyCredential
from approaches.customchatreadretrieveread import CustomChatReadRetrieveReadApproach
from approaches.defaultchatreadretrieveread import DefaultChatReadRetrieveReadApproach
import time
import json
from flask import jsonify
import re

# Replace these with your own values, either in environment variables or directly here
# AZURE_STORAGE_ACCOUNT = os.environ.get("AZURE_STORAGE_ACCOUNT") or "##"
# AZURE_STORAGE_CONTAINER = os.environ.get("AZURE_STORAGE_CONTAINER") or "##"
# AZURE_SEARCH_SERVICE = os.environ.get("AZURE_SEARCH_SERVICE") or "##"
# AZURE_SEARCH_INDEX = os.environ.get("AZURE_SEARCH_INDEX") or "##"
# AZURE_OPENAI_SERVICE = os.environ.get("AZURE_OPENAI_SERVICE") or "##"
# AZURE_OPENAI_TEXT_DAVINCI_DEPLOYMENT = os.environ.get("AZURE_OPENAI_TEXT_DAVINCI_DEPLOYMENT") or "##"
# AZURE_OPENAI_GPT_TURBO_DEPLOYMENT = os.environ.get("AZURE_OPENAI_GPT_TURBO_DEPLOYMENT") or "##"
# AZURE_OPENAI_SERVICE_KEY = os.environ.get("AZURE_OPENAI_SERVICE_KEY") or "##"
# AZURE_SEARCH_SERVICE_KEY = os.environ.get("AZURE_SEARCH_SERVICE_KEY") or "##"
# AZURE_SEARCH_SERVICE_PROD_KEY = os.environ.get("AZURE_SEARCH_SERVICE_PROD_KEY") or "##"
# AZURE_STORAGE_ACCOUNT_KEY = os.environ.get("AZURE_STORAGE_ACCOUNT_KEY") or "##"

# Replace these with your own values, either in environment variables or directly here
AZURE_STORAGE_ACCOUNT = os.environ.get("AZURE_STORAGE_ACCOUNT") or "#AZURE_STORAGE_ACCOUNT#"
AZURE_STORAGE_CONTAINER = os.environ.get("AZURE_STORAGE_CONTAINER") or "#AZURE_STORAGE_CONTAINER#"
AZURE_SEARCH_SERVICE = os.environ.get("AZURE_SEARCH_SERVICE") or "#AZURE_SEARCH_SERVICE#"
AZURE_SEARCH_INDEX = os.environ.get("AZURE_SEARCH_INDEX") or "#AZURE_SEARCH_INDEX#"
AZURE_OPENAI_SERVICE = os.environ.get("AZURE_OPENAI_SERVICE") or "#AZURE_OPENAI_SERVICE#"
AZURE_OPENAI_TEXT_DAVINCI_DEPLOYMENT = os.environ.get("AZURE_OPENAI_TEXT_DAVINCI_DEPLOYMENT") or "#AZURE_OPENAI_TEXT_DAVINCI_DEPLOYMENT#"
AZURE_OPENAI_GPT_TURBO_DEPLOYMENT = os.environ.get("AZURE_OPENAI_GPT_TURBO_DEPLOYMENT") or "#AZURE_OPENAI_GPT_TURBO_DEPLOYMENT#"

AZURE_OPENAI_SERVICE_KEY = os.environ.get("AZURE_OPENAI_SERVICE_KEY") or "#AZURE_OPENAI_SERVICE_KEY#"
AZURE_SEARCH_SERVICE_KEY = os.environ.get("AZURE_SEARCH_SERVICE_KEY") or "#AZURE_SEARCH_SERVICE_KEY#"
AZURE_SEARCH_SERVICE_PROD_KEY = os.environ.get("AZURE_SEARCH_SERVICE_PROD_KEY") or "#AZURE_SEARCH_SERVICE_PROD_KEY#"
AZURE_STORAGE_ACCOUNT_KEY = os.environ.get("AZURE_STORAGE_ACCOUNT_KEY") or "#AZURE_STORAGE_ACCOUNT_KEY#"

KB_FIELDS_CONTENT = os.environ.get("KB_FIELDS_CONTENT") or "content"
KB_FIELDS_CATEGORY = os.environ.get("KB_FIELDS_CATEGORY") or "category"
KB_FIELDS_SOURCEPAGE = os.environ.get("KB_FIELDS_SOURCEPAGE") or "sourcepage"

# Use the current user identity to authenticate with Azure OpenAI, Cognitive Search, and Blob Storage (no secrets needed,
# just use 'az login' locally, and managed identity when deployed on Azure). If you need to use keys, use separate AzureKeyCredential instances with the
# keys for each service
# If you encounter a blocking error during a DefaultAzureCredntial resolution, you can exclude the problematic credential by using a parameter (ex. exclude_shared_token_cache_credential=True)
azure_credential = DefaultAzureCredential()

# Used by the OpenAI SDK
openai.api_type = "azure"
openai.api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com"
openai.api_version = "2023-03-15-preview"

# Comment these two lines out if using keys, set your API key in the OPENAI_API_KEY environment variable instead
# openai.api_type = "azure_ad"
# openai_token = azure_credential.get_token("https://cognitiveservices.azure.com/.default")
openai.api_key = AZURE_OPENAI_SERVICE_KEY
ENDPOINT = "rg-openai-dreamdemo"
# Set up clients for Cognitive Search and Storage
search_client = SearchClient(
    endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
    index_name=AZURE_SEARCH_INDEX,
    credential=AzureKeyCredential(AZURE_SEARCH_SERVICE_KEY))
blob_client = BlobServiceClient(
    account_url=f"https://{AZURE_STORAGE_ACCOUNT}.blob.core.windows.net",
    credential=AZURE_STORAGE_ACCOUNT_KEY)
custom_blob_client = BlobServiceClient(
    account_url = f"https://{AZURE_STORAGE_ACCOUNT}.blob.core.windows.net",credential=AZURE_STORAGE_ACCOUNT_KEY)


blob_container = blob_client.get_container_client(AZURE_STORAGE_CONTAINER)

# Various approaches to integrate GPT and external knowledge, most applications will use a single one of these patterns
# or some derivative, here we include several for exploration purposes
ask_approaches = {
    "rtr": RetrieveThenReadApproach(search_client, AZURE_OPENAI_TEXT_DAVINCI_DEPLOYMENT, KB_FIELDS_SOURCEPAGE, KB_FIELDS_CONTENT),
    "rrr": ReadRetrieveReadApproach(search_client, AZURE_OPENAI_TEXT_DAVINCI_DEPLOYMENT, KB_FIELDS_SOURCEPAGE, KB_FIELDS_CONTENT),
    "rda": ReadDecomposeAsk(search_client, AZURE_OPENAI_TEXT_DAVINCI_DEPLOYMENT, KB_FIELDS_SOURCEPAGE, KB_FIELDS_CONTENT)
}

chat_approaches = {
    "rrr": ChatReadRetrieveReadApproach(search_client, AZURE_OPENAI_GPT_TURBO_DEPLOYMENT, AZURE_OPENAI_TEXT_DAVINCI_DEPLOYMENT, KB_FIELDS_SOURCEPAGE, KB_FIELDS_CONTENT)
}



def ensure_openai_token():
    return AZURE_OPENAI_SERVICE_KEY
    # global openai_token
    # if openai_token.expires_on < int(time.time()) - 60:
    #     openai_token = azure_credential.get_token("https://cognitiveservices.azure.com/.default")
    #     openai.api_key = openai_token.token

app = func.FunctionApp()
@app.function_name(name="content")
@app.route(route="content/{path}",auth_level=func.AuthLevel.ANONYMOUS)
def content_file(req: func.HttpRequest) -> func.HttpResponse:
    container = req.params.get('container')
    path = req.route_params.get('path')
 
    
    if container:
        blob = custom_blob_client.get_container_client(container).get_blob_client(path).download_blob()
    else:
        blob = blob_container.get_blob_client(path).download_blob()
        
    mime_type = blob.properties["content_settings"]["content_type"]
    if mime_type == "application/octet-stream":
        mime_type = mimetypes.guess_type(path)[0] or "application/octet-stream"
    response = func.HttpResponse(blob.readall())
    response.headers['Content-Type'] = mime_type
    response.headers["Content-Disposition"] =  f"inline; filename={path}"
    return response

@app.function_name(name="ask")
@app.route(route="ask",auth_level=func.AuthLevel.ANONYMOUS)
def ask(req: func.HttpRequest) -> func.HttpResponse:
    ensure_openai_token()
    req_body = req.get_json()
    approach = req_body["approach"]
    try:
        impl = ask_approaches.get(approach)
        if not impl:
            return json.dumps({"error": "unknown approach"}), 400
        r = impl.run(req_body["question"], req_body.get("overrides") or {})
        response = func.HttpResponse(json.dumps(r))
        response.headers['Content-Type'] = 'application/json'
        return response  
    except Exception as e:
        logging.exception("Exception in /ask")
        return json.dumps({"error": str(e)}), 500

@app.function_name(name="chat")
@app.route(route="chat",auth_level=func.AuthLevel.ANONYMOUS)
def chat(req: func.HttpRequest) -> func.HttpResponse:
    ensure_openai_token()
    approach = req.get_json()["approach"]
    use_public_information = req.get_json().get("enableExternalDomain") or False
    custom_index = req.get_json().get("index") or False
    company = req.get_json().get("company") or "resai"
    industry = req.get_json().get("industry") or "resai"
    prompt_config = req.get_json().get("promptConfig") or {}
    match = False
    # if not custom_index and (not use_public_information):
    #     answer = {"data_points": [], "answer": "Sorry, but we couldn't locate any document in the knowledge base. Please upload the relevant documents." , "thoughts": ""}

    #     response =  func.HttpResponse(json.dumps(answer), status_code=200)
    #     response.headers['Content-Type'] = 'application/json'
    #     return response 
    if industry != 'resai':
        company = industry
    if custom_index:
        if '-' in custom_index and len(custom_index.split('-')[1]) == 13:
            match = True
    if match:
        try:
            logging.info("inside match")
            custom_search_client = SearchClient(
                endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
                # endpoint="https://srch-openai-prod.search.windows.net",
                index_name=custom_index,
                credential=AzureKeyCredential(AZURE_SEARCH_SERVICE_PROD_KEY))
            customCRR = DefaultChatReadRetrieveReadApproach(custom_search_client, AZURE_OPENAI_GPT_TURBO_DEPLOYMENT, AZURE_OPENAI_TEXT_DAVINCI_DEPLOYMENT, KB_FIELDS_SOURCEPAGE, KB_FIELDS_CONTENT)
            
            r = customCRR.run(req.get_json()["history"], req.get_json().get("overrides") or {}, use_public_information,company, prompt_config)
            print("after approaches")
            logging.info("got the final response")
            logging.info("custom search")
            
            if company == 'recipe':
                r['pictures'] = {"eggs": f"https://{AZURE_STORAGE_ACCOUNT}.blob.core.windows.net/contoso-cg-shopping/eggs.jpg","bread": f"https://{AZURE_STORAGE_ACCOUNT}.blob.core.windows.net/contoso-cg-shopping/bread.jpg"}
            response = func.HttpResponse(json.dumps(r))
            response.headers['Content-Type'] = 'application/json'
            return response  
        except Exception as e:
            error_message = {"error":"An error occurred while processing the request."}
            response = func.HttpResponse(json.dumps(error_message), status_code=500)
            response.headers['Content-Type'] = 'application/json'
            return response  
    
   
    elif not match and custom_index and company != 'resai':
        custom_search_client = SearchClient(
            endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
            index_name=custom_index,
            credential=AzureKeyCredential(AZURE_SEARCH_SERVICE_PROD_KEY))
        customCRR = CustomChatReadRetrieveReadApproach(custom_search_client, AZURE_OPENAI_GPT_TURBO_DEPLOYMENT, AZURE_OPENAI_TEXT_DAVINCI_DEPLOYMENT, KB_FIELDS_SOURCEPAGE, KB_FIELDS_CONTENT)
        r = customCRR.run(req.get_json()["history"], req.get_json().get("overrides") or {}, use_public_information,company, prompt_config)
        if company == 'recipe':
            r['pictures'] = {"eggs": f"https://{AZURE_STORAGE_ACCOUNT}.blob.core.windows.net/contoso-cg-shopping/eggs.jpg","bread": f"https://{AZURE_STORAGE_ACCOUNT}.blob.core.windows.net/contoso-cg-shopping/bread.jpg"}
        response = func.HttpResponse(json.dumps(r))
        response.headers['Content-Type'] = 'application/json'
        return response  
    
    try:
        impl = chat_approaches.get(approach)
        if not impl:
            return json.dumps({"error": "unknown approach"}), 400
        r = impl.run(req.get_json()["history"], req.get_json().get("overrides") or {}, use_public_information,company, prompt_config)
        response = func.HttpResponse(json.dumps(r))
        response.headers['Content-Type'] = 'application/json'
        return response
    except Exception as e:
        logging.exception("Exception in /chat")
        return json.dumps({"error": str(e)}), 500
