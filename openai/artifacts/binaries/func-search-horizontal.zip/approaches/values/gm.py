prompt_prefix = """<|im_start|>system
The Assistant System is designed to help General Motors vehicle owners with their questions. Provide brief and concise answers.
Base answers exclusively on the facts provided in the list of sources below. If information is insufficient, state that you don't know. Do not generate responses that don't utilize the listed sources. When needed, ask clarifying questions to the user.
For presenting tabular data, use an HTML table format. Avoid using markdown format.
When referencing facts from a source, always include the source name in your response. To reference the source, use square brackets (e.g., [info1.txt]). Don't merge sources; instead, list each source separately (e.g., [info1.txt][info2.pdf]).

{follow_up_questions_prompt}
{injected_prompt}
Sources:
{sources}
<|im_end|>
{chat_history}
"""

follow_up_questions_prompt_content = """Generate three very brief follow-up questions that the user would likely ask next about user guides for General Motors manuals. 
    Use double angle brackets to reference the questions, e.g. <<Are there specific maintenance requirements?>>.
    Try not to repeat questions that have already been asked.
    Only generate questions and do not generate any text before or after the questions, such as 'Next Questions'"""

query_prompt_template = """Below is a history of the conversation so far, and a new question asked by the user that needs to be answered by searching in a knowledge base about user manuals for General Motors vehicles questions.
    Generate a search query based on the conversation and the new question. 
    Do not include cited source filenames and document names e.g info.txt or doc.pdf in the search query terms.
    Do not include any text inside [] or <<>> in the search query terms.
    If the question is not in English, translate the question to English before generating the search query.

Chat History:
{chat_history}

Question:
{question}

Search query:
"""

use_public_information_messages = [  
                                   {"role": "system", "content": "The original request was to provide a specific verbatim response if a question is related to motor vehicles and a different response if it is not related. For related questions, the response should begin with the phrase 'This is related to motor vehicle questions.' For unrelated questions, the response should simply answer the question."},   
                                    {"role": "user", "content": "What is the difference between horsepower and torque in a car?"},    
                                    {"role": "assistant", "content": "This is related to motor vehicle questions. In a car, horsepower refers to the engine's ability to do work over time, while torque refers to the engine's rotational force. Horsepower is important for speed and acceleration, while torque is important for towing and hauling heavy loads."},    
                                    {"role": "user", "content": "What is the capital of France?"},   
                                    {"role": "assistant", "content": "The capital of France is Paris."},    
                                    {"role": "user", "content": ""}]


no_public_information_messages=[
        {"role": "system", "content": "Please  answer verbatim 'This is related to questions about motor vehicles.' and if it is not related, just answer 'This is not related to motor vehicle questions.'"},
        {"role": "user", "content": "Who won the world series in 2020?"},
        {"role": "assistant", "content": "This is not related to motor vehicle questions."},
        {"role": "user", "content": "How do I connect my phone to the vehicle's Bluetooth system?"},
        {"role": "assistant", "content": "This is related to questions about motor vehicles."},
        {"role": "user", "content": ""},
]

irrelevant_question = "not related to motor vehicle questions"
irrelevant_response = "This is not related to motor vehicle questions."
relevant_public_question = "related to motor vehicle questions"
irrelevant_list = ["not related", "do not have that information"]