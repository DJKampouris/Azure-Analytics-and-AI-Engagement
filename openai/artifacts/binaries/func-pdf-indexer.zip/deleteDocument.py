import logging
import azure.functions as func
import os
import argparse
import glob
import html
import io
import re
import time
import json
import tempfile
import PyPDF2
from azure.core.credentials import AzureKeyCredential
from pypdf import PdfReader, PdfWriter
from azure.core.credentials import AzureKeyCredential
from azure.storage.blob import BlobServiceClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import ( SearchIndex, PrioritizedFields, SemanticField, SemanticSettings, SimpleField, SearchableField, SemanticConfiguration)
from azure.search.documents import SearchClient
from azure.ai.formrecognizer import DocumentAnalysisClient
import random
import multiprocessing
import string
MAX_SECTION_LENGTH = 1000
SENTENCE_SEARCH_LIMIT = 100
SECTION_OVERLAP = 100
search_service_name = os.environ.get("SEARCH_SERVICE_NAME")
search_service_key = os.environ.get("SEARCH_SERVICE_KEY")
storage_account_key = os.environ.get("STORAGE_ACCOUNT_KEY")
storage_account_name = os.environ.get("STORAGE_ACCOUNT_NAME")
form_recognizer_key = os.environ.get("FORM_RECOGNIZER_KEY")
search_creds = AzureKeyCredential(search_service_key)
formrecognizer_creds = AzureKeyCredential(form_recognizer_key)





def remove_from_index(filename,index_name):

    search_client = SearchClient(endpoint=f"https://{search_service_name}.search.windows.net/",
                                    index_name=index_name,
                                    credential=search_creds)
    while True:
        filter = None if filename == None else f"sourcefile eq '{os.path.basename(filename)}'"
        r = search_client.search("", filter=filter, top=1000, include_total_count=True)
        if r.get_count() == 0:
            break
        r = search_client.delete_documents(documents=[{ "id": d["id"] } for d in r])

        # It can take a few seconds for search results to reflect changes, so wait a bit
        time.sleep(2)

index_list = ['finance', 'gm-demo','gm-demo-test','gptkbindex','healthcare','ralph-lauren','ralph-lauren-v2','retail']
def deleteDocument(index,file):
    logging.info('Python HTTP trigger function processed a request.')
    try:
    # Get the file from the request
     
    
        index_name_ = index
        file_name_ = file
        

        if index_name_ not in index_list:
            remove_from_index(file_name_,index_name_)
            output = {
                "index_name": index_name_,
                "file_name": file_name_
            }
            # response = func.HttpResponse(json.dumps(output))
            # response.headers['Content-Type'] = 'application/json'
            return output
        else:
            output = {
                "error": f'{index_name_} index name not allowed'
            }
            # response = func.HttpResponse(json.dumps(output))
            # response.headers['Content-Type'] = 'application/json'
            return output

    except Exception as e:
        logging.info("in except")
        logging.info(e)

    else:
        return func.HttpResponse(
             "Please pass a PDF file in the request.",
             status_code=400
        )




